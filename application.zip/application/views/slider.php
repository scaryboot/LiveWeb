<section id="slider">
	<div class="container">
				<div class="row">
					<div class="col-sm-12">
						<div id="slider-carousel" class="carousel slide" data-ride="carousel">
							<ol class="carousel-indicators">
								<li data-target="#slider-carousel" data-slide-to="0" class="active"></li>
								<li data-target="#slider-carousel" data-slide-to="1"></li>
								<li data-target="#slider-carousel" data-slide-to="2"></li>
							</ol>
							
							<div class="carousel-inner">
								<div class="item active">
									<div class="col-sm-6">
										<h1><span>Sinar</span>-Jaya</h1>
										<h2>E-commerce OtoCars</h2>
										<p>ready stock all part SUV, convertible, couple, hatcback, minivan and sedan </p>
										<button type="button" class="btn btn-default get">Get it now</button>
									</div>
									<div class="col-sm-6">
										<img src="<?php echo base_url()."asset/";?>images/home/cars1.jpg" class="girl img-responsive" alt="" />
										<img src="<?php echo base_url()."asset/";?>images/home/pricing.png"  class="pricing" alt="" />
									</div>
								</div>
								<div class="item">
									<div class="col-sm-6">
										<h1><span>Sinar</span>-Jaya</h1>
										<h2>Send all item what do u want</h2>
										<p>deliver with JNE, Tiki and DHL </p>
										<button type="button" class="btn btn-default get">Get it now</button>
									</div>
									<div class="col-sm-6">
										<img src="<?php echo base_url()."asset/";?>images/home/cars2.jpg" class="girl img-responsive" alt="" />
										<img src="<?php echo base_url()."asset/";?>images/home/pricing.png"  class="pricing" alt="" />
									</div>
								</div>
								
								<div class="item">
									<div class="col-sm-6">
										<h1><span>Sinar</span>-Jaya</h1>
										<h2>easy shop and complete item</h2>
										<p>we have original, replica and OEM item</p>
										<button type="button" class="btn btn-default get">Get it now</button>
									</div>
									<div class="col-sm-6">
										<img src="<?php echo base_url()."asset/";?>images/home/cars3.jpg" class="girl img-responsive" alt="" />
										<img src="<?php echo base_url()."asset/";?>images/home/pricing.png" class="pricing" alt="" />
									</div>
								</div>
								
							</div>
							
							<a href="#slider-carousel" class="left control-carousel hidden-xs" data-slide="prev">
								<i class="fa fa-angle-left"></i>
							</a>
							<a href="#slider-carousel" class="right control-carousel hidden-xs" data-slide="next">
								<i class="fa fa-angle-right"></i>
							</a>
						</div>
						
					</div>
				</div>
			</div>
</section>